﻿using DeweyDecimalLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeweyDecimalLibrary.Tree_Structure
{
    public class GlobalTree
    {
        // static class 
        public static Tree<DeweyPair> Tree { get; set; }
    }
}
