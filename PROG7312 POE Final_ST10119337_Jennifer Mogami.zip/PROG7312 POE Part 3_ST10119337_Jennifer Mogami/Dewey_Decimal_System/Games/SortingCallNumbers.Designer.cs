﻿namespace Dewey_Decimal_System
{
    partial class frmSortingCallNumbers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSortingCallNumbers));
            this.lstboxRandom = new System.Windows.Forms.ListBox();
            this.lstboxSorted = new System.Windows.Forms.ListBox();
            this.lblCountdown = new System.Windows.Forms.Label();
            this.lblCountdownEdit = new System.Windows.Forms.Label();
            this.btnUp = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.toolTipUp = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipDown = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipLbox1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // lstboxRandom
            // 
            this.lstboxRandom.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lstboxRandom.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lstboxRandom.FormattingEnabled = true;
            this.lstboxRandom.ItemHeight = 25;
            this.lstboxRandom.Location = new System.Drawing.Point(123, 73);
            this.lstboxRandom.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lstboxRandom.Name = "lstboxRandom";
            this.lstboxRandom.Size = new System.Drawing.Size(210, 204);
            this.lstboxRandom.TabIndex = 0;
            this.toolTipLbox1.SetToolTip(this.lstboxRandom, "Drag the item from this list box to the other to play the game. Sort the Items in" +
        " ascending order.");
            this.lstboxRandom.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lstboxRandom_MouseDown);
            // 
            // lstboxSorted
            // 
            this.lstboxSorted.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lstboxSorted.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lstboxSorted.FormattingEnabled = true;
            this.lstboxSorted.ItemHeight = 25;
            this.lstboxSorted.Location = new System.Drawing.Point(357, 73);
            this.lstboxSorted.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lstboxSorted.Name = "lstboxSorted";
            this.lstboxSorted.Size = new System.Drawing.Size(212, 204);
            this.lstboxSorted.TabIndex = 1;
            this.lstboxSorted.DragDrop += new System.Windows.Forms.DragEventHandler(this.lstboxSorted_DragDrop);
            this.lstboxSorted.DragEnter += new System.Windows.Forms.DragEventHandler(this.lstboxSorted_DragEnter);
            // 
            // lblCountdown
            // 
            this.lblCountdown.AutoSize = true;
            this.lblCountdown.BackColor = System.Drawing.Color.Transparent;
            this.lblCountdown.Font = new System.Drawing.Font("Perpetua Titling MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCountdown.ForeColor = System.Drawing.Color.Transparent;
            this.lblCountdown.Location = new System.Drawing.Point(129, 27);
            this.lblCountdown.Name = "lblCountdown";
            this.lblCountdown.Size = new System.Drawing.Size(141, 34);
            this.lblCountdown.TabIndex = 2;
            this.lblCountdown.Text = "Timer : ";
            // 
            // lblCountdownEdit
            // 
            this.lblCountdownEdit.AutoSize = true;
            this.lblCountdownEdit.BackColor = System.Drawing.Color.Transparent;
            this.lblCountdownEdit.Font = new System.Drawing.Font("Perpetua Titling MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCountdownEdit.ForeColor = System.Drawing.Color.Transparent;
            this.lblCountdownEdit.Location = new System.Drawing.Point(391, 27);
            this.lblCountdownEdit.Name = "lblCountdownEdit";
            this.lblCountdownEdit.Size = new System.Drawing.Size(102, 34);
            this.lblCountdownEdit.TabIndex = 4;
            this.lblCountdownEdit.Text = "00:00";
            // 
            // btnUp
            // 
            this.btnUp.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnUp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUp.BackgroundImage")));
            this.btnUp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnUp.Location = new System.Drawing.Point(599, 108);
            this.btnUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(62, 51);
            this.btnUp.TabIndex = 5;
            this.toolTipUp.SetToolTip(this.btnUp, "Select a call number and then press this button to move the call number up in the" +
        " listbox.");
            this.btnUp.UseVisualStyleBackColor = false;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // btnDown
            // 
            this.btnDown.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDown.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDown.BackgroundImage")));
            this.btnDown.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnDown.Location = new System.Drawing.Point(599, 215);
            this.btnDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(62, 51);
            this.btnDown.TabIndex = 6;
            this.toolTipDown.SetToolTip(this.btnDown, "Select a call number and then press this button to move the call number down in t" +
        "he listbox.");
            this.btnDown.UseVisualStyleBackColor = false;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // toolTipUp
            // 
            this.toolTipUp.IsBalloon = true;
            this.toolTipUp.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTipUp.ToolTipTitle = "Move Item Up";
            // 
            // toolTipDown
            // 
            this.toolTipDown.IsBalloon = true;
            this.toolTipDown.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTipDown.ToolTipTitle = "Move Item Down";
            // 
            // toolTipLbox1
            // 
            this.toolTipLbox1.IsBalloon = true;
            this.toolTipLbox1.ToolTipTitle = "Drag Items";
            // 
            // frmSortingCallNumbers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(700, 355);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.btnUp);
            this.Controls.Add(this.lblCountdownEdit);
            this.Controls.Add(this.lblCountdown);
            this.Controls.Add(this.lstboxSorted);
            this.Controls.Add(this.lstboxRandom);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.Name = "frmSortingCallNumbers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SortingCallNumbers";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmSortingCallNumbers_FormClosed);
            this.Load += new System.EventHandler(this.frmSortingCallNumbers_Load);
            this.MouseHover += new System.EventHandler(this.frmSortingCallNumbers_MouseHover);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ListBox lstboxRandom;
        private ListBox lstboxSorted;
        private Label lblCountdown;
        private Label lblCountdownEdit;
        private Button btnUp;
        private Button btnDown;
        private ToolTip toolTipUp;
        private ToolTip toolTipDown;
        private ToolTip toolTipLbox1;
    }
}